from sounds import *
from erb import *
from filtering import *
from hrtf import *

dB = 1.