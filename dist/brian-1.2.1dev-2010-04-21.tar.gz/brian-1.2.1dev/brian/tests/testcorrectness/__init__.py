'''
Created on 4 sept. 2009

@author: goodman
'''

#if __name__=='__main__':
#    import nose
#    nose.main()