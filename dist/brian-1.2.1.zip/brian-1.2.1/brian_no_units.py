from brian_unit_prefs import turn_off_units
import warnings
turn_off_units()
warnings.warn("Turning off units")
