from numpy import *
from numpy.random import *
from __init__ import *

x = randn(3)
print exp(x)
print fastexp(x)
