from brian_unit_prefs import turn_off_units
turn_off_units(warn=False)
